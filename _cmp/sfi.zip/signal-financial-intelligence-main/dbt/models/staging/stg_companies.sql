select * from {{ ref('companies') }}
