import axios from "axios";

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:8000",
  headers: {
    "X-Signal-Key": import.meta.env.VITE_SIGNAL_KEY || "",
    "Content-Type": "application/json",
  },
});
